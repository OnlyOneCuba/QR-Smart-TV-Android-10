package com.wifiqr.tv;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.util.EnumMap;
import java.util.Map;

public class MainActivity extends Activity {

    private EditText ssid, password;
    private Spinner security;
    private CheckBox hidden;
    private ImageView qr;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        ssid = findViewById(R.id.ssid);
        password = findViewById(R.id.password);
        security = findViewById(R.id.security);
        hidden = findViewById(R.id.hidden);
        qr = findViewById(R.id.qr);
        Button gen = findViewById(R.id.generate);

        security.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                getResources().getStringArray(R.array.security)));

        gen.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { generate(); }
        });

        prefillSsid();
    }

    /** Intenta rellenar el SSID actual. La contraseña NO se puede leer sin root. */
    private void prefillSsid() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                return;
            }
            readSsid();
        } catch (Throwable ignored) { }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        try { readSsid(); } catch (Throwable ignored) { }
    }

    private void readSsid() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm == null) return;
        WifiInfo info = wm.getConnectionInfo();
        if (info == null) return;
        String s = info.getSSID();
        if (s == null || s.equals("<unknown ssid>")) return;
        if (s.startsWith("\"") && s.endsWith("\"") && s.length() > 1)
            s = s.substring(1, s.length() - 1);
        if (ssid.getText().length() == 0) ssid.setText(s);
    }

    private static String esc(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '\\' || c == ';' || c == ',' || c == ':' || c == '"') sb.append('\\');
            sb.append(c);
        }
        return sb.toString();
    }

    private void generate() {
        String name = ssid.getText().toString();
        String pass = password.getText().toString();
        int sec = security.getSelectedItemPosition();
        if (name.isEmpty()) {
            Toast.makeText(this, "Escribe el nombre de la red", Toast.LENGTH_SHORT).show();
            return;
        }
        String type = sec == 0 ? "WPA" : sec == 1 ? "WEP" : "nopass";
        StringBuilder w = new StringBuilder("WIFI:T:").append(type)
                .append(";S:").append(esc(name)).append(";");
        if (sec != 2) w.append("P:").append(esc(pass)).append(";");
        if (hidden.isChecked()) w.append("H:true;");
        w.append(";");

        try {
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.MARGIN, 2);
            int size = 640;
            BitMatrix m = new QRCodeWriter().encode(w.toString(), BarcodeFormat.QR_CODE, size, size, hints);
            int[] px = new int[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                    px[y * size + x] = m.get(x, y) ? Color.BLACK : Color.WHITE;
            Bitmap bmp = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888);
            qr.setImageBitmap(bmp);
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
